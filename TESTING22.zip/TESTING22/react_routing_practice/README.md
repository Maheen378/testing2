# React Routing Practice

## Run in VS Code
1. Extract the ZIP and open `react_routing_practice` in VS Code.
2. Open Terminal > New Terminal.
3. Run `npm install` and then `npm run dev`.
4. Open the local URL shown in the terminal (usually http://localhost:5173).

This project demonstrates navbar navigation using React Router: `BrowserRouter`, `Routes`, `Route`, `Link` and `NavLink`.
