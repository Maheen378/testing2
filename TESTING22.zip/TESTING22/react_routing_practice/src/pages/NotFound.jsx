import { Link } from "react-router-dom";
export default function NotFound() { return <main className="container py-5 text-center"><h1>404 - Page Not Found</h1><p className="text-secondary">The page does not exist.</p><Link className="btn btn-primary" to="/">Go Home</Link></main>; }
