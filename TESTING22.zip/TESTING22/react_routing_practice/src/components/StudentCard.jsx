
function StudentCard() {
  return (
    <div className="container mt-4">
      <div className="card p-4 shadow-sm">
        <h2>Student Card</h2>
        <p><strong>Name:</strong> Maheen</p>
        <p><strong>Department:</strong> Software Engineering</p>
        <p><strong>Semester:</strong> 5th</p>
      </div>
    </div>
  );
}

export default StudentCard;
