import { NavLink } from "react-router-dom";
export default function Navbar() {
  const linkClass = ({ isActive }) => `nav-link ${isActive ? "active fw-bold text-warning" : "text-white"}`;
  return <nav className="navbar navbar-dark bg-dark"><div className="container">
    <NavLink className="navbar-brand fw-bold" to="/">MyWebsite</NavLink>
    <div className="navbar-nav ms-auto flex-row flex-wrap gap-2">
      <NavLink className={linkClass} to="/">Home</NavLink>
      <NavLink className={linkClass} to="/about">About</NavLink>
      <NavLink className={linkClass} to="/services">Services</NavLink>
      <NavLink className={linkClass} to="/contact">Contact</NavLink>
      <NavLink to="/student-form">Student Form</NavLink>
<NavLink to="/student-card">Student Card</NavLink>
    </div>
  </div></nav>;
}
