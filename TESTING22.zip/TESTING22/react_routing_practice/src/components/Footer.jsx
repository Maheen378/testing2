function Footer() {
  return (
    <footer className="bg-dark text-white text-center p-3 mt-5">
      <p className="mb-0">
        © 2026 MyWebsite. All Rights Reserved.
      </p>
    </footer>
  );
}

export default Footer;